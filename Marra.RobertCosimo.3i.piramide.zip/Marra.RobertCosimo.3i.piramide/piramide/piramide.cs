
using System;

namespace Piramide{
    public class Piramide {
        
        int mattoni = 84;
        int piani = Piani(mattoni);
        int rimanenti = Rimanenti(mattoni, piani);
        public static int Piani( int mattoni )
        {
            int piani = 0;
            int mattoniUsati = 0;
            while (mattoniUsati <= mattoni){
                piani++;
                mattoniUsati += piani * piani;
            }
            return piani - 1;
        }
        public static int Rimanenti( int mattoni, int piani )
        {
            int mattoniUsati = 0;
            for (int i = 1; i<= piani; i++){
                mattoniUsati += i* i;
            }
            return mattoni - mattoniUsati;
        }

        internal static int Rimanenti(int mattoni)
        {
            throw new NotImplementedException();
        }
    }
}